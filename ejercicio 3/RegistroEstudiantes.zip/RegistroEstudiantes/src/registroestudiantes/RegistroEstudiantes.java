package registroestudiantes;


public class RegistroEstudiantes {

    public static void main(String[] args) {


        FormularioRegistro ventana = new FormularioRegistro();


        ventana.setVisible(true);


    }

}