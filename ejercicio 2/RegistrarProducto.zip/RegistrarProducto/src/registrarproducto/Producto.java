package registrarproducto;

public class Producto {

    // Atributos
    private String nombre;
    private double precio;

    //  CONSTRUCTOR
    public Producto(String nombre, double precio) {

        this.nombre = nombre;
        this.precio = precio;

    }
    // Método para mostrar datos
    public String mostrarDatos(){

        return "Producto: " + nombre +
                "\nPrecio: S/ " + precio;

    }

}