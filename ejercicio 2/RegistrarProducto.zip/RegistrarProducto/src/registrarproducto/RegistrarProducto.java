package registrarproducto;

public class RegistrarProducto {

    public static void main(String[] args) {

        FormularioRegistro ventana = new FormularioRegistro();

        ventana.setVisible(true);

    }
}