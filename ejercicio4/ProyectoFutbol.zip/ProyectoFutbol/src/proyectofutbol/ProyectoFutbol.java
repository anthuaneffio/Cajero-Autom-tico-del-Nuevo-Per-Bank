import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

// ============================================================
// CLASE JUGADOR
// Representa a un jugador con su número, nombre automático
// y sus estadísticas individuales durante el partido.
// ============================================================
class Jugador {
    private int numero;
    private String nombre;
    private int goles;
    private int faltas;
    private int amarillas;
    private boolean expulsado;

    public Jugador(int numero) {
        this.numero = numero;
        this.nombre = "Jugador " + numero; // nombre automático, sin pedirlo por Scanner
        this.goles = 0;
        this.faltas = 0;
        this.amarillas = 0;
        this.expulsado = false;
    }

    public int getNumero() { return numero; }
    public String getNombre() { return nombre; }
    public int getGoles() { return goles; }
    public int getFaltas() { return faltas; }
    public int getAmarillas() { return amarillas; }
    public boolean estaExpulsado() { return expulsado; }

    public void marcarGol() { goles++; }
    public void marcarFalta() { faltas++; }

    // Si el jugador ya tenía una amarilla, la segunda lo expulsa (regla real de fútbol).
    // Devuelve true si terminó expulsado por doble amarilla.
    public boolean marcarAmarilla() {
        amarillas++;
        if (amarillas >= 2) {
            expulsado = true;
            return true;
        }
        return false;
    }

    public void marcarRojaDirecta() {
        expulsado = true;
    }
}

// ============================================================
// CLASE EQUIPO
// Agrupa 30 jugadores, controla los goles del equipo y
// permite elegir un jugador aleatorio que no esté expulsado.
// ============================================================
class Equipo {
    private String nombre;
    private ArrayList<Jugador> jugadores;
    private int golesEquipo;
    private int posesionMinutos; // acumulador: minutos en que este equipo tuvo el balón

    public Equipo(String nombre) {
        this.nombre = nombre;
        this.jugadores = new ArrayList<>();
        this.golesEquipo = 0;
        this.posesionMinutos = 0;
    }

    public void agregarJugador(Jugador j) {
        jugadores.add(j);
    }

    public String getNombre() { return nombre; }
    public ArrayList<Jugador> getJugadores() { return jugadores; }
    public int getGolesEquipo() { return golesEquipo; }
    public void sumarGol() { golesEquipo++; }
    public void sumarPosesion() { posesionMinutos++; }
    public int getPosesionMinutos() { return posesionMinutos; }

    // Elige un jugador al azar dentro del equipo que NO esté expulsado.
    // Usa la misma técnica de "generar y comprobar" que usamos para los 60 números.
    public Jugador jugadorAleatorio(Random random) {
        Jugador elegido;
        do {
            int indice = random.nextInt(jugadores.size());
            elegido = jugadores.get(indice);
        } while (elegido.estaExpulsado());
        return elegido;
    }

    // Recorre los jugadores del equipo y devuelve el goleador (mayor cantidad de goles).
    public Jugador goleadorDelEquipo() {
        Jugador goleador = jugadores.get(0);
        for (Jugador j : jugadores) {
            if (j.getGoles() > goleador.getGoles()) {
                goleador = j;
            }
        }
        return goleador;
    }
}

// ============================================================
// CLASE ARBITRO
// Representa al árbitro del partido. No decide los eventos
// (eso lo hace Random dentro de Partido).
// ============================================================
class Arbitro {
    private String nombre;

    public Arbitro(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() { return nombre; }
}

// ============================================================
// CLASE HISTOGRAMA
// Guarda las cantidades finales de cada tipo de evento y las
// muestra como barras de asteriscos en consola.
// ============================================================
class Histograma {
    private int goles;
    private int faltas;
    private int amarillas;
    private int rojas;
    private int corners;
    private int tirosLibres;
    private int penales;
    private int cambios;

    public void setDatos(int goles, int faltas, int amarillas, int rojas,
                          int corners, int tirosLibres, int penales, int cambios) {
        this.goles = goles;
        this.faltas = faltas;
        this.amarillas = amarillas;
        this.rojas = rojas;
        this.corners = corners;
        this.tirosLibres = tirosLibres;
        this.penales = penales;
        this.cambios = cambios;
    }

    // Construye una fila de asteriscos, uno por cada ocurrencia del evento.
    private String barra(int cantidad) {
        String linea = "";
        for (int i = 0; i < cantidad; i++) {
            linea = linea + "*";
        }
        return linea;
    }

    public void mostrar() {
        System.out.println("Goles        " + barra(goles) + " (" + goles + ")");
        System.out.println("Faltas       " + barra(faltas) + " (" + faltas + ")");
        System.out.println("Amarillas    " + barra(amarillas) + " (" + amarillas + ")");
        System.out.println("Rojas        " + barra(rojas) + " (" + rojas + ")");
        System.out.println("Corners      " + barra(corners) + " (" + corners + ")");
        System.out.println("Tiros libres " + barra(tirosLibres) + " (" + tirosLibres + ")");
        System.out.println("Penales      " + barra(penales) + " (" + penales + ")");
        System.out.println("Cambios      " + barra(cambios) + " (" + cambios + ")");
    }
}

// ============================================================
// CLASE PARTIDO
// Controla la simulación completa: recorre los 90 minutos (más
// el tiempo añadido), genera eventos aleatorios.
// ============================================================
class Partido {
    private Equipo equipoA;
    private Equipo equipoB;
    private Arbitro arbitro;
    private Random random;

    private int totalFaltas;
    private int totalAmarillas;
    private int totalRojas;
    private int totalCambios;
    private int totalTirosLibres;
    private int totalPenales;
    private int totalCorners;

    // Acumulador de texto: va guardando la línea de cada evento del partido.
    private String historial;

    public Partido(Equipo equipoA, Equipo equipoB, Arbitro arbitro) {
        this.equipoA = equipoA;
        this.equipoB = equipoB;
        this.arbitro = arbitro;
        this.random = new Random();
        this.historial = "";
    }

    // Elige al azar cuál de los dos equipos genera el evento de este minuto.
    private Equipo equipoAleatorio() {
        int numero = random.nextInt(2); // 0 o 1
        if (numero == 0) {
            return equipoA;
        } else {
            return equipoB;
        }
    }

    private void registrar(int minuto, String texto) {
        historial = historial + "Minuto " + minuto + ": " + texto + "\n";
        System.out.println("Minuto " + minuto + ": " + texto);
    }

    public void jugar() {
        // Tiempo añadido aleatorio: entre 0 y 5 minutos extra.
        int tiempoAnadido = random.nextInt(6);
        int minutosTotales = 90 + tiempoAnadido;

        System.out.println("=========================================");
        System.out.println("Comienza el partido: " + equipoA.getNombre() + " vs " + equipoB.getNombre());
        System.out.println("Arbitro: " + arbitro.getNombre());
        System.out.println("=========================================");

        for (int minuto = 1; minuto <= minutosTotales; minuto++) {

            // Cada minuto se sortea qué equipo tiene el balón (para la posesión).
            Equipo conBalon = equipoAleatorio();
            conBalon.sumarPosesion();

            // No en cada minuto pasa algo relevante: se sortea un número 1-100.
            int evento = random.nextInt(100) + 1;

            if (evento <= 8) {
                // GOL (1-8)
                Equipo equipoQueAnota = equipoAleatorio();
                Jugador goleador = equipoQueAnota.jugadorAleatorio(random);
                goleador.marcarGol();
                equipoQueAnota.sumarGol();
                registrar(minuto, "GOL de " + goleador.getNombre() + " (" + equipoQueAnota.getNombre() + ")");

            } else if (evento <= 30) {
                // FALTA (9-30)
                Equipo equipoQueComete = equipoAleatorio();
                Jugador infractor = equipoQueComete.jugadorAleatorio(random);
                infractor.marcarFalta();
                totalFaltas++;
                registrar(minuto, "Falta de " + infractor.getNombre() + " (" + equipoQueComete.getNombre() + ")");

            } else if (evento <= 40) {
                // TARJETA AMARILLA (31-40), puede derivar en roja por doble amarilla
                Equipo equipoQueComete = equipoAleatorio();
                Jugador infractor = equipoQueComete.jugadorAleatorio(random);
                boolean expulsadoPorDoble = infractor.marcarAmarilla();
                totalAmarillas++;
                if (expulsadoPorDoble) {
                    totalRojas++;
                    registrar(minuto, "Doble amarilla -> ROJA para " + infractor.getNombre() + " (" + equipoQueComete.getNombre() + ")");
                } else {
                    registrar(minuto, "Tarjeta amarilla para " + infractor.getNombre() + " (" + equipoQueComete.getNombre() + ")");
                }

            } else if (evento <= 45) {
                // TARJETA ROJA DIRECTA (41-45)
                Equipo equipoQueComete = equipoAleatorio();
                Jugador infractor = equipoQueComete.jugadorAleatorio(random);
                infractor.marcarRojaDirecta();
                totalRojas++;
                registrar(minuto, "Tarjeta ROJA directa para " + infractor.getNombre() + " (" + equipoQueComete.getNombre() + ")");

            } else if (evento <= 55) {
                // CORNER (46-55)
                Equipo equipoQueTira = equipoAleatorio();
                totalCorners++;
                registrar(minuto, "Corner para " + equipoQueTira.getNombre());

            } else if (evento <= 65) {
                // TIRO LIBRE (56-65)
                Equipo equipoQueTira = equipoAleatorio();
                totalTirosLibres++;
                registrar(minuto, "Tiro libre para " + equipoQueTira.getNombre());

            } else if (evento <= 70) {
                // PENAL (66-70)
                Equipo equipoQueTira = equipoAleatorio();
                Jugador pateador = equipoQueTira.jugadorAleatorio(random);
                totalPenales++;
                int resultadoPenal = random.nextInt(100) + 1;
                if (resultadoPenal <= 75) {
                    pateador.marcarGol();
                    equipoQueTira.sumarGol();
                    registrar(minuto, "PENAL cobrado y GOL de " + pateador.getNombre() + " (" + equipoQueTira.getNombre() + ")");
                } else {
                    registrar(minuto, "PENAL fallado por " + pateador.getNombre() + " (" + equipoQueTira.getNombre() + ")");
                }

            } else if (evento <= 76) {
                // CAMBIO / SUSTITUCION (71-76)
                Equipo equipoQueCambia = equipoAleatorio();
                Jugador sale = equipoQueCambia.jugadorAleatorio(random);
                totalCambios++;
                registrar(minuto, "Cambio en " + equipoQueCambia.getNombre() + ": sale " + sale.getNombre());

            } else if (evento <= 80) {
                // LESION (77-80): obliga a un cambio forzado
                Equipo equipoConLesion = equipoAleatorio();
                Jugador lesionado = equipoConLesion.jugadorAleatorio(random);
                totalCambios++;
                registrar(minuto, "Lesion de " + lesionado.getNombre() + " (" + equipoConLesion.getNombre() + "), cambio obligado");
            }
           
        }

        mostrarResultadoFinal(minutosTotales);
    }

    private void mostrarResultadoFinal(int minutosTotales) {
        System.out.println();
        System.out.println("====================================");
        System.out.println("          RESULTADO FINAL");
        System.out.println("====================================");
        System.out.println(equipoA.getNombre() + ": " + equipoA.getGolesEquipo() + " goles");
        System.out.println(equipoB.getNombre() + ": " + equipoB.getGolesEquipo() + " goles");
        System.out.println("(Minutos jugados: " + minutosTotales + ")");

        System.out.println();
        System.out.println("------------------------------------");
        System.out.println("ESTADISTICAS");
        System.out.println("------------------------------------");
        System.out.println("Faltas: " + totalFaltas);
        System.out.println("Tarjetas amarillas: " + totalAmarillas);
        System.out.println("Tarjetas rojas: " + totalRojas);
        System.out.println("Cambios: " + totalCambios);
        System.out.println("Tiros libres: " + totalTirosLibres);
        System.out.println("Penales: " + totalPenales);
        System.out.println("Corners: " + totalCorners);

        int totalMinutos = equipoA.getPosesionMinutos() + equipoB.getPosesionMinutos();
        double posesionA = (equipoA.getPosesionMinutos() * 100.0) / totalMinutos;
        double posesionB = (equipoB.getPosesionMinutos() * 100.0) / totalMinutos;
        System.out.println();
        System.out.println("Posesion: " + equipoA.getNombre() + " " + Math.round(posesionA) + "% - "
                + equipoB.getNombre() + " " + Math.round(posesionB) + "%");

        Jugador goleadorA = equipoA.goleadorDelEquipo();
        Jugador goleadorB = equipoB.goleadorDelEquipo();
        System.out.println();
        System.out.println("Goleador " + equipoA.getNombre() + ": " + goleadorA.getNombre() + " (" + goleadorA.getGoles() + " goles)");
        System.out.println("Goleador " + equipoB.getNombre() + ": " + goleadorB.getNombre() + " (" + goleadorB.getGoles() + " goles)");

        System.out.println();
        System.out.println("------------------------------------");
        System.out.println("HISTOGRAMA DE EVENTOS");
        System.out.println("------------------------------------");
        Histograma histograma = new Histograma();
        int totalGoles = equipoA.getGolesEquipo() + equipoB.getGolesEquipo();
        histograma.setDatos(totalGoles, totalFaltas, totalAmarillas, totalRojas,
                totalCorners, totalTirosLibres, totalPenales, totalCambios);
        histograma.mostrar();

        System.out.println();
        System.out.println("------------------------------------");
        System.out.println("HISTORIAL CRONOLOGICO");
        System.out.println("------------------------------------");
        System.out.print(historial);
    }
}

// ============================================================
// CLASE MAIN
// Punto de entrada: registra los equipos, genera los 60
// jugadores sin repetir (sin arrays, usando ArrayList), reparte
// 30 y 30, pide el nombre del arbitro y ejecuta la simulacion.
// Permite repetir el partido para demostrar que Random cambia
// los resultados en cada ejecucion.
// ============================================================
public class ProyectoFutbol {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Random random = new Random();

        System.out.println("=========================================");
        System.out.println("     SIMULADOR DE PARTIDO DE FUTBOL");
        System.out.println("=========================================");

        System.out.print("Nombre del primer equipo: ");
        String nombreA = sc.nextLine();

        System.out.print("Nombre del segundo equipo: ");
        String nombreB = sc.nextLine();

        System.out.print("Nombre del arbitro: ");
        String nombreArbitro = sc.nextLine();

        String jugarOtraVez = "s";

        while (jugarOtraVez.equalsIgnoreCase("s")) {

            // ---- Generamos los 60 numeros de jugador sin repetir ----
            ArrayList<Jugador> todosLosJugadores = new ArrayList<>();
            while (todosLosJugadores.size() < 60) {
                int numero = random.nextInt(60) + 1;

                boolean yaExiste = false;
                for (Jugador j : todosLosJugadores) {
                    if (j.getNumero() == numero) {
                        yaExiste = true;
                        break;
                    }
                }

                if (!yaExiste) {
                    todosLosJugadores.add(new Jugador(numero));
                }
            }

            // ---- Repartimos: los primeros 30 al Equipo A, los otros 30 al Equipo B ----
            Equipo equipoA = new Equipo(nombreA);
            Equipo equipoB = new Equipo(nombreB);
            for (int i = 0; i < todosLosJugadores.size(); i++) {
                if (i < 30) {
                    equipoA.agregarJugador(todosLosJugadores.get(i));
                } else {
                    equipoB.agregarJugador(todosLosJugadores.get(i));
                }
            }

            Arbitro arbitro = new Arbitro(nombreArbitro);

            // ---- Simulamos el partido ----
            Partido partido = new Partido(equipoA, equipoB, arbitro);
            partido.jugar();

            System.out.println();
            System.out.print("¿Jugar otra simulacion? (s/n): ");
            jugarOtraVez = sc.nextLine();
        }

        System.out.println("Fin del programa.");
        sc.close();
    }
}